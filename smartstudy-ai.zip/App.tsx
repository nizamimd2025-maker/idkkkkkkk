import React, { useState, useEffect, useRef } from 'react';
import { Camera, Mic, Type, Book, MessageCircle, Settings, History, Moon, Sun, Check, Lock, ChevronRight, X, Image as ImageIcon, Sparkles } from 'lucide-react';
import { Quiz, Question, ViewState, UserStats, ChatMessage } from './types';
import { generateQuizFromContent, performOCR } from './services/gemini';
import { QuizPlayer } from './components/QuizPlayer';
import { ChatTutor } from './components/ChatTutor';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

// --- Sub Components (Internal for simplicity) ---

const SubscriptionModal: React.FC<{ isOpen: boolean; onClose: () => void; onSubscribe: () => void }> = ({ isOpen, onClose, onSubscribe }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-br from-indigo-500 to-purple-600 opacity-20" />
        <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-black/5 dark:bg-white/10 rounded-full hover:bg-black/10 transition-colors z-10">
          <X size={20} className="text-gray-600 dark:text-gray-300" />
        </button>
        
        <div className="relative z-10 text-center mt-4">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg mb-6 text-white">
            <Sparkles size={32} />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Unlock SmartStudy Pro</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-8">Get unlimited access to the most powerful AI study tools.</p>
          
          <ul className="text-left space-y-4 mb-8">
            {[
              "Unlimited AI Scans & Questions",
              "Detailed Step-by-Step Solutions",
              "Ad-free Experience",
              "Advanced AI Tutor Model",
              "Unlimited Quizzes"
            ].map((feature, i) => (
              <li key={i} className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
                <div className="p-1 bg-green-100 dark:bg-green-900/30 rounded-full">
                  <Check size={14} className="text-green-600 dark:text-green-400" />
                </div>
                {feature}
              </li>
            ))}
          </ul>

          <div className="p-4 rounded-xl border-2 border-primary-600 bg-primary-50 dark:bg-primary-900/10 mb-6 relative">
             <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                Best Value
             </div>
             <div className="flex justify-between items-center">
                <span className="font-semibold text-gray-900 dark:text-white">Monthly Plan</span>
                <span className="text-xl font-bold text-primary-600">$5.00 <span className="text-sm font-normal text-gray-500">/mo</span></span>
             </div>
          </div>

          <button 
            onClick={onSubscribe}
            className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/30 active:scale-95 transition-all"
          >
            Start Pro Subscription
          </button>
          <p className="text-xs text-gray-400 mt-4 text-center">Cancel anytime. No commitment.</p>
        </div>
      </div>
    </div>
  );
};

// --- Main App Component ---

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('home');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [isPro, setIsPro] = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  
  // Data State
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [history, setHistory] = useState<Quiz[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [tutorContext, setTutorContext] = useState<Question | null>(null);
  const [stats, setStats] = useState<UserStats>({
    quizzesTaken: 0,
    totalQuestionsAnswered: 0,
    correctAnswers: 0,
    streakDays: 3,
    lastActive: Date.now()
  });

  // Input State
  const [textInput, setTextInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [ocrText, setOcrText] = useState('');
  const [showEditor, setShowEditor] = useState(false);
  const [imgPreview, setImgPreview] = useState<string | null>(null);

  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Effects ---

  useEffect(() => {
    // Load theme
    const savedTheme = localStorage.getItem('theme') as 'light'|'dark' || 'light';
    setTheme(savedTheme);
    if (savedTheme === 'dark') document.documentElement.classList.add('dark');
  }, []);

  useEffect(() => {
    // Save theme
    localStorage.setItem('theme', theme);
    if (theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [theme]);

  // --- Handlers ---

  const handleToggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const handleSubscribe = () => {
    setIsPro(true);
    setShowPaywall(false);
    alert("Welcome to Pro! (Simulation)");
  };

  const checkLimit = () => {
    if (isPro) return true;
    // Mock daily limit
    const todayUses = parseInt(localStorage.getItem('todayUses') || '0');
    if (todayUses >= 3) {
      setShowPaywall(true);
      return false;
    }
    localStorage.setItem('todayUses', (todayUses + 1).toString());
    return true;
  };

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!checkLimit()) return;
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const base64 = ev.target?.result as string;
        setImgPreview(base64);
        setIsProcessing(true);
        try {
          // 1. OCR
          const extractedText = await performOCR(base64.split(',')[1]);
          setOcrText(extractedText);
          setShowEditor(true); // User reviews text before quiz gen
        } catch (err) {
          alert("Failed to read image.");
        } finally {
          setIsProcessing(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVoiceInput = () => {
    if (!checkLimit()) return;
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Voice input not supported in this browser.");
      return;
    }
    
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onstart = () => setIsProcessing(true);
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setTextInput(transcript);
      setIsProcessing(false);
    };
    
    recognition.onerror = () => {
        setIsProcessing(false);
        alert("Could not hear you. Try again.");
    };
  };

  const generateQuiz = async (text: string, imgData?: string) => {
    if (!text.trim() && !imgData) return;
    setIsProcessing(true);
    try {
      const questions = await generateQuizFromContent(text, imgData ? imgData.split(',')[1] : undefined);
      if (questions.length === 0) {
        alert("Could not generate questions. Try more text.");
        return;
      }

      const newQuiz: Quiz = {
        id: Date.now().toString(),
        title: "Generated Quiz", // Could use LLM to title it
        createdAt: Date.now(),
        questions,
        completed: false,
        originalText: text
      };
      
      setActiveQuiz(newQuiz);
      setView('quiz');
      
      // Clean up input states
      setTextInput('');
      setOcrText('');
      setImgPreview(null);
      setShowEditor(false);

    } catch (e) {
      alert("AI is busy. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  // --- Views ---

  const renderHome = () => (
    <div className="flex flex-col h-full max-w-xl mx-auto px-6 py-8">
      <header className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">SmartStudy AI</h1>
          <p className="text-gray-500 text-sm">Homework Helper</p>
        </div>
        <button onClick={handleToggleTheme} className="p-2 rounded-full bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-300">
          {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
        </button>
      </header>

      {/* Hero Input Section */}
      <div className="flex-1 flex flex-col justify-center gap-6 pb-20">
        
        {/* Camera Card */}
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="group relative overflow-hidden bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl p-8 text-white shadow-xl shadow-indigo-500/20 transition-all hover:scale-[1.02] active:scale-95"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 blur-2xl transition-transform group-hover:scale-150" />
          <div className="relative z-10 flex flex-col items-start">
            <div className="p-3 bg-white/20 backdrop-blur-md rounded-2xl mb-4">
              <Camera size={32} />
            </div>
            <h2 className="text-2xl font-bold mb-1">Scan Homework</h2>
            <p className="text-indigo-100 text-sm">Take a photo to get answers & quizzes.</p>
          </div>
          <input 
            type="file" 
            accept="image/*" 
            ref={fileInputRef} 
            onChange={handleImageSelect} 
            className="hidden" 
          />
        </button>

        <div className="grid grid-cols-2 gap-4">
          {/* Voice Input */}
          <button 
            onClick={handleVoiceInput}
            className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col items-center justify-center gap-3 transition-all active:scale-95"
          >
            <div className="p-3 bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 rounded-2xl">
              <Mic size={24} />
            </div>
            <span className="font-semibold text-gray-800 dark:text-gray-200">Voice</span>
          </button>

          {/* Type Input */}
          <button 
            onClick={() => {
                setTextInput('');
                setShowEditor(true);
            }}
            className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col items-center justify-center gap-3 transition-all active:scale-95"
          >
             <div className="p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-2xl">
              <Type size={24} />
            </div>
            <span className="font-semibold text-gray-800 dark:text-gray-200">Type</span>
          </button>
        </div>

        {/* Pro Banner */}
        {!isPro && (
          <div onClick={() => setShowPaywall(true)} className="mt-4 p-4 bg-gradient-to-r from-gray-900 to-gray-800 dark:from-gray-800 dark:to-gray-700 rounded-2xl flex items-center justify-between text-white cursor-pointer shadow-lg">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-500/20 rounded-lg text-yellow-400"><Sparkles size={18}/></div>
              <div>
                <p className="font-bold text-sm">Go Pro</p>
                <p className="text-xs text-gray-400">Unlimited scans & tutor chat</p>
              </div>
            </div>
            <ChevronRight size={18} className="text-gray-400" />
          </div>
        )}
      </div>

      {/* Loading Overlay */}
      {isProcessing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm">
           <div className="flex flex-col items-center">
             <div className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mb-4" />
             <p className="font-medium text-gray-600 dark:text-gray-300">Thinking...</p>
           </div>
        </div>
      )}

      {/* Text Editor Modal (for Voice/Type/OCR correction) */}
      {(showEditor || textInput || ocrText) && !isProcessing && (
        <div className="fixed inset-0 z-40 bg-white dark:bg-slate-950 flex flex-col animate-in slide-in-from-bottom-5">
           <div className="p-4 border-b dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-950">
              <button onClick={() => { setShowEditor(false); setOcrText(''); setTextInput(''); setImgPreview(null); }} className="text-gray-500">Cancel</button>
              <h3 className="font-bold text-lg">Review Content</h3>
              <button 
                onClick={() => generateQuiz(ocrText || textInput, imgPreview || undefined)}
                className="text-primary-600 font-bold"
              >
                Generate
              </button>
           </div>
           <div className="flex-1 p-6 overflow-y-auto">
             {imgPreview && (
                <div className="mb-4 rounded-xl overflow-hidden shadow-md max-h-48 object-cover">
                    <img src={imgPreview} alt="Scan" className="w-full" />
                </div>
             )}
             <textarea 
               value={ocrText || textInput}
               onChange={(e) => ocrText ? setOcrText(e.target.value) : setTextInput(e.target.value)}
               placeholder="Type your question here..."
               className="w-full h-64 text-lg bg-transparent border-none focus:ring-0 resize-none text-gray-900 dark:text-white placeholder-gray-400"
               autoFocus
             />
           </div>
        </div>
      )}
    </div>
  );

  const renderHistory = () => (
    <div className="p-6 pb-24 h-full overflow-y-auto no-scrollbar">
      <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">History</h2>
      <div className="space-y-4">
        {history.length === 0 ? (
          <p className="text-gray-500 text-center mt-10">No quizzes taken yet.</p>
        ) : (
          history.slice().reverse().map(quiz => (
            <div key={quiz.id} className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700">
               <div className="flex justify-between items-start mb-2">
                 <h3 className="font-bold text-gray-800 dark:text-white truncate pr-4">
                   {quiz.questions[0]?.text.substring(0, 30)}...
                 </h3>
                 <span className={`text-xs px-2 py-1 rounded-full ${quiz.completed ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    {quiz.score}/{quiz.questions.length}
                 </span>
               </div>
               <p className="text-xs text-gray-400 mb-4">{new Date(quiz.createdAt).toLocaleDateString()}</p>
               <button 
                 onClick={() => { setActiveQuiz(quiz); setView('quiz'); }}
                 className="w-full py-2 bg-gray-50 dark:bg-slate-700 text-gray-900 dark:text-white rounded-lg text-sm font-medium"
               >
                 Review Quiz
               </button>
            </div>
          ))
        )}
      </div>
    </div>
  );

  const renderStats = () => {
    // Dummy Data for chart
    const data = [
        { name: 'Mon', score: 2 },
        { name: 'Tue', score: 4 },
        { name: 'Wed', score: 3 },
        { name: 'Thu', score: 8 },
        { name: 'Fri', score: 5 },
        { name: 'Sat', score: 9 },
        { name: 'Sun', score: 6 },
    ];

    return (
        <div className="p-6 pb-24 h-full overflow-y-auto no-scrollbar">
            <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Your Progress</h2>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700">
                    <p className="text-gray-500 text-xs mb-1">Streak</p>
                    <p className="text-2xl font-black text-orange-500 flex items-center gap-1">
                        {stats.streakDays} <span className="text-sm text-gray-400 font-normal">days</span>
                    </p>
                </div>
                <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700">
                    <p className="text-gray-500 text-xs mb-1">Total Answered</p>
                    <p className="text-2xl font-black text-primary-600">
                        {stats.totalQuestionsAnswered}
                    </p>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-slate-700 mb-6">
                <h3 className="font-bold text-gray-800 dark:text-white mb-4">Weekly Activity</h3>
                <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data}>
                            <XAxis dataKey="name" tick={{fontSize: 12, fill: '#9ca3af'}} axisLine={false} tickLine={false} />
                            <YAxis hide />
                            <Tooltip 
                                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                            />
                            <Line type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={3} dot={{r: 4, fill: '#4f46e5', strokeWidth: 2, stroke: '#fff'}} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {!isPro && (
                <div className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-3xl p-6 text-white text-center">
                    <Sparkles className="mx-auto mb-2" />
                    <h3 className="font-bold text-lg mb-1">Go Pro for Analytics</h3>
                    <p className="text-sm opacity-80 mb-4">See detailed breakdowns of your weak spots.</p>
                    <button onClick={() => setShowPaywall(true)} className="bg-white text-primary-600 px-6 py-2 rounded-xl font-bold text-sm">Upgrade - $5/mo</button>
                </div>
            )}
        </div>
    );
  };

  const renderSettings = () => (
     <div className="p-6 pb-24 h-full overflow-y-auto no-scrollbar">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Settings</h2>
        
        <div className="space-y-6">
            <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-slate-700">
                <div className="p-4 border-b border-gray-100 dark:border-slate-700 flex justify-between items-center">
                    <span className="text-gray-900 dark:text-white font-medium">Dark Mode</span>
                    <button 
                        onClick={handleToggleTheme}
                        className={`w-12 h-6 rounded-full p-1 transition-colors ${theme === 'dark' ? 'bg-primary-600' : 'bg-gray-200'}`}
                    >
                        <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${theme === 'dark' ? 'translate-x-6' : 'translate-x-0'}`} />
                    </button>
                </div>
                <div className="p-4 flex justify-between items-center">
                    <span className="text-gray-900 dark:text-white font-medium">Save Scans Locally</span>
                    <div className="w-12 h-6 rounded-full p-1 bg-green-500">
                         <div className="w-4 h-4 rounded-full bg-white shadow-sm translate-x-6" />
                    </div>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-slate-700">
                <div className="p-4 border-b border-gray-100 dark:border-slate-700">
                    <h3 className="font-bold text-gray-900 dark:text-white mb-1">Subscription</h3>
                    <p className="text-sm text-gray-500">Current Plan: <span className="font-semibold text-primary-600">{isPro ? 'Pro' : 'Free'}</span></p>
                </div>
                {!isPro ? (
                    <button onClick={() => setShowPaywall(true)} className="w-full p-4 text-left text-primary-600 font-medium hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
                        Upgrade to Pro ($5/mo)
                    </button>
                ) : (
                    <button onClick={() => { setIsPro(false); alert("Subscription Cancelled"); }} className="w-full p-4 text-left text-red-500 font-medium hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
                        Cancel Subscription
                    </button>
                )}
            </div>

            <div className="text-center text-xs text-gray-400 mt-8">
                SmartStudy AI v1.0.0
            </div>
        </div>
     </div>
  );

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-gray-50 dark:bg-slate-950 font-sans">
      
      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {view === 'home' && renderHome()}
        
        {view === 'quiz' && activeQuiz && (
            <QuizPlayer 
                quiz={activeQuiz} 
                onComplete={(score) => {
                    // Update stats
                    setStats(prev => ({
                        ...prev,
                        quizzesTaken: prev.quizzesTaken + 1,
                        totalQuestionsAnswered: prev.totalQuestionsAnswered + activeQuiz.questions.length,
                        correctAnswers: prev.correctAnswers + score
                    }));
                    // Save to History
                    const completedQuiz = { ...activeQuiz, score, completed: true };
                    setHistory(prev => [...prev, completedQuiz]);
                    // If we update the quiz object itself in state it might cause loop if not careful, 
                    // but for player it's fine.
                }}
                onExit={() => setView('home')}
                onAskTutor={(question) => {
                    setTutorContext(question);
                    setView('tutor');
                }}
            />
        )}

        {view === 'tutor' && (
            <ChatTutor 
                initialContext={tutorContext}
                history={chatHistory}
                onUpdateHistory={setChatHistory}
                isPro={isPro}
                onUpgrade={() => setShowPaywall(true)}
            />
        )}

        {view === 'history' && renderHistory()}
        {view === 'settings' && renderStats()} 
        {/* Using settings icon for stats/profile combined for simplicity, or separating? 
            Let's put stats in "History" tab or a separate one? 
            Prompt asks for: Home, Type/Voice(part of home), Quiz(view), Tutor, Notes(History), Settings.
            I will use the "Settings" tab to house the toggle and profile/stats.
        */}
        {view === 'paywall' && renderSettings()} {/* Mapping "settings" view to settings render */}

      </main>

      {/* Bottom Navigation */}
      <nav className="h-20 bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-slate-800 flex items-center justify-around px-2 pb-2 z-20 shrink-0">
         <button onClick={() => setView('home')} className={`p-3 rounded-2xl flex flex-col items-center gap-1 transition-all ${view === 'home' ? 'text-primary-600 bg-primary-50 dark:bg-primary-900/20' : 'text-gray-400'}`}>
            <Camera size={24} />
            <span className="text-[10px] font-medium">Scan</span>
         </button>

         <button onClick={() => setView('tutor')} className={`p-3 rounded-2xl flex flex-col items-center gap-1 transition-all ${view === 'tutor' ? 'text-primary-600 bg-primary-50 dark:bg-primary-900/20' : 'text-gray-400'}`}>
            <MessageCircle size={24} />
            <span className="text-[10px] font-medium">Tutor</span>
         </button>

         <button onClick={() => setView('history')} className={`p-3 rounded-2xl flex flex-col items-center gap-1 transition-all ${view === 'history' ? 'text-primary-600 bg-primary-50 dark:bg-primary-900/20' : 'text-gray-400'}`}>
            <History size={24} />
            <span className="text-[10px] font-medium">History</span>
         </button>

         <button onClick={() => setView('paywall')} className={`p-3 rounded-2xl flex flex-col items-center gap-1 transition-all ${view === 'paywall' ? 'text-primary-600 bg-primary-50 dark:bg-primary-900/20' : 'text-gray-400'}`}>
            <Settings size={24} />
            <span className="text-[10px] font-medium">Settings</span>
         </button>
      </nav>

      {/* Global Modals */}
      <SubscriptionModal isOpen={showPaywall} onClose={() => setShowPaywall(false)} onSubscribe={handleSubscribe} />
    </div>
  );
};

export default App;
