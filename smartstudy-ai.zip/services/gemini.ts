import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Question, QuestionType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Schema for Quiz Generation
const quizSchema: Schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      type: { type: Type.STRING, enum: ['mcq', 'true_false', 'short_answer', 'fill_blank'] },
      text: { type: Type.STRING, description: "The question text" },
      correctAnswer: { type: Type.STRING, description: "The correct answer" },
      distractors: { 
        type: Type.ARRAY, 
        items: { type: Type.STRING },
        description: "2-4 wrong answers for MCQ or True/False"
      },
      solutionSteps: { 
        type: Type.ARRAY, 
        items: { type: Type.STRING },
        description: "Step by step solution"
      },
      difficulty: { type: Type.STRING, enum: ['easy', 'medium', 'hard'] },
      explanation: { type: Type.STRING, description: "Concise explanation of the answer" }
    },
    required: ["id", "type", "text", "correctAnswer", "solutionSteps", "difficulty", "explanation"]
  }
};

export const generateQuizFromContent = async (text: string, imageData?: string): Promise<Question[]> => {
  const model = "gemini-2.5-flash";
  
  const prompt = `You are an expert tutor. Analyze the following content (image or text) and generate a study quiz for a high school student.
  Create 3-5 distinct questions based on the key concepts found in the content.
  Ensure questions vary in difficulty.
  IMPORTANT: Return ONLY the JSON array matching the schema.`;

  const parts: any[] = [{ text: prompt }];

  if (imageData) {
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: imageData
      }
    });
  }
  
  parts.push({ text: `Source content: ${text}` });

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: quizSchema,
        systemInstruction: "You are a helpful and strict educational AI."
      }
    });

    const jsonText = response.text || "[]";
    return JSON.parse(jsonText) as Question[];
  } catch (error) {
    console.error("Gemini Quiz Gen Error:", error);
    throw new Error("Failed to generate quiz. Please try again.");
  }
};

export const chatWithTutor = async (history: {role: string, parts: {text: string}[]}[], message: string, context?: string): Promise<string> => {
  const model = "gemini-2.5-flash";
  
  let systemInstruction = "You are SmartStudy AI, a patient, encouraging, and teen-friendly tutor. Keep answers concise but helpful. Use emojis occasionally. Explain concepts step-by-step.";
  
  if (context) {
    systemInstruction += `\n\nCurrent Context/Problem being discussed: ${context}`;
  }

  try {
    const chat = ai.chats.create({
      model,
      history: history,
      config: {
        systemInstruction
      }
    });

    const result = await chat.sendMessage({ message });
    return result.text || "I'm having trouble thinking right now. Try again?";
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "Sorry, I lost my connection. Can you repeat that?";
  }
};

export const performOCR = async (imageBase64: string): Promise<string> => {
  // We use the multimodal model to extract text
  const model = "gemini-2.5-flash";
  try {
    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: imageBase64 } },
          { text: "Transcribe all the text in this image exactly as it appears. Ignore layout, just give me the text content." }
        ]
      }
    });
    return response.text || "";
  } catch (e) {
    console.error("OCR Error:", e);
    throw new Error("Could not read image.");
  }
};
