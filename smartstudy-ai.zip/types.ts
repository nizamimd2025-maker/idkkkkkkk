export enum QuestionType {
  MCQ = 'mcq',
  TRUE_FALSE = 'true_false',
  SHORT_ANSWER = 'short_answer',
  FILL_BLANK = 'fill_blank'
}

export interface Question {
  id: string;
  type: QuestionType;
  text: string;
  correctAnswer: string;
  distractors?: string[]; // For MCQ
  solutionSteps: string[];
  difficulty: 'easy' | 'medium' | 'hard';
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  createdAt: number;
  questions: Question[];
  score?: number;
  completed: boolean;
  originalText?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  relatedQuizId?: string;
}

export interface UserStats {
  quizzesTaken: number;
  totalQuestionsAnswered: number;
  correctAnswers: number;
  streakDays: number;
  lastActive: number;
}

export type ViewState = 'home' | 'quiz' | 'tutor' | 'history' | 'settings' | 'paywall';
