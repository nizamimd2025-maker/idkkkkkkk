import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, Question } from '../types';
import { Send, Bot, User, Sparkles } from 'lucide-react';
import { chatWithTutor } from '../services/gemini';

interface ChatTutorProps {
  initialContext?: Question | null;
  history: ChatMessage[];
  onUpdateHistory: (msgs: ChatMessage[]) => void;
  isPro: boolean;
  onUpgrade: () => void;
}

export const ChatTutor: React.FC<ChatTutorProps> = ({ initialContext, history, onUpdateHistory, isPro, onUpgrade }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [history]);

  useEffect(() => {
    // If opened with specific context, send an automatic system prompt logic or a user prompt stub?
    // Let's just have the context ready. The user usually initiates "Can you explain this?"
    if (initialContext && history.length === 0) {
        const contextMsg: ChatMessage = {
            id: Date.now().toString(),
            role: 'model',
            text: `Hi! I see you're working on: "${initialContext.text}". What part is confusing you?`,
            timestamp: Date.now()
        };
        onUpdateHistory([contextMsg]);
    }
  }, [initialContext]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    // Check free limit
    if (!isPro && history.filter(m => m.role === 'user').length >= 5) {
        alert("You've reached the free message limit for this session. Go Pro for unlimited chats!");
        onUpgrade();
        return;
    }

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    const newHistory = [...history, userMsg];
    onUpdateHistory(newHistory);
    setInput('');
    setIsLoading(true);

    try {
      // Convert history to Gemini format
      const apiHistory = newHistory.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      // Remove last user message from history param as it is sent as 'message'
      apiHistory.pop(); 

      const contextStr = initialContext 
        ? `Question: ${initialContext.text}\nCorrect Answer: ${initialContext.correctAnswer}\nSteps: ${initialContext.solutionSteps.join(' -> ')}` 
        : undefined;

      const responseText = await chatWithTutor(apiHistory, userMsg.text, contextStr);

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: Date.now()
      };
      onUpdateHistory([...newHistory, botMsg]);

    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 dark:bg-slate-950">
      <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-24 no-scrollbar">
        {history.length === 0 && !initialContext && (
          <div className="flex flex-col items-center justify-center h-full opacity-50">
            <Bot size={64} className="mb-4 text-primary-400" />
            <p className="text-center text-lg">Ask me anything about your homework!</p>
          </div>
        )}
        
        {initialContext && (
            <div className="bg-primary-50 dark:bg-primary-900/20 border border-primary-200 dark:border-primary-800 p-3 rounded-xl text-sm mb-4">
                <p className="font-semibold text-primary-800 dark:text-primary-200 mb-1">Current Focus:</p>
                <p className="text-gray-700 dark:text-gray-300 italic">"{initialContext.text}"</p>
            </div>
        )}

        {history.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-4 shadow-sm ${
                msg.role === 'user'
                  ? 'bg-primary-600 text-white rounded-br-sm'
                  : 'bg-white dark:bg-slate-800 text-gray-800 dark:text-gray-200 rounded-bl-sm border border-gray-100 dark:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-2 mb-1 opacity-70 text-xs">
                {msg.role === 'user' ? <User size={12} /> : <Bot size={12} />}
                <span>{msg.role === 'user' ? 'You' : 'SmartStudy Tutor'}</span>
              </div>
              <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
            </div>
          </div>
        ))}
        {isLoading && (
            <div className="flex justify-start">
                <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl rounded-bl-sm shadow-sm border border-gray-100 dark:border-slate-700">
                    <div className="flex gap-1">
                        <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></span>
                        <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></span>
                        <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></span>
                    </div>
                </div>
            </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-slate-900/90 backdrop-blur-md border-t dark:border-slate-800 z-10">
        <div className="max-w-2xl mx-auto flex gap-2">
            {!isPro && history.filter(m => m.role === 'user').length >= 3 && (
                <button onClick={onUpgrade} className="absolute -top-12 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-400 to-orange-500 text-white text-xs px-3 py-1 rounded-full shadow-lg flex items-center gap-1 animate-pulse">
                    <Sparkles size={12}/> Upgrade for Unlimited Chat
                </button>
            )}
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your question..."
            className="flex-1 p-3.5 bg-gray-100 dark:bg-slate-800 border-0 rounded-xl focus:ring-2 focus:ring-primary-500 text-gray-900 dark:text-white"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="p-3.5 bg-primary-600 text-white rounded-xl shadow-lg hover:bg-primary-700 disabled:opacity-50 disabled:shadow-none transition-all"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};
