import React, { useState } from 'react';
import { Quiz, Question, QuestionType } from '../types';
import { CheckCircle, XCircle, ChevronRight, RefreshCcw, BookOpen, MessageCircle } from 'lucide-react';

interface QuizPlayerProps {
  quiz: Quiz;
  onComplete: (score: number) => void;
  onExit: () => void;
  onAskTutor: (question: Question) => void;
}

export const QuizPlayer: React.FC<QuizPlayerProps> = ({ quiz, onComplete, onExit, onAskTutor }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [showSummary, setShowSummary] = useState(false);

  const currentQuestion = quiz.questions[currentIndex];
  const isLastQuestion = currentIndex === quiz.questions.length - 1;

  const handleSubmit = () => {
    setIsSubmitted(true);
    // Simple normalization for text comparison
    const isCorrect = selectedAnswer.trim().toLowerCase() === currentQuestion.correctAnswer.trim().toLowerCase();
    
    if (isCorrect) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    if (isLastQuestion) {
      setShowSummary(true);
      onComplete(score + (isCorrect(currentQuestion) ? 0 : 0)); // Add last point if just handled
    } else {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer('');
      setIsSubmitted(false);
    }
  };

  const isCorrect = (q: Question) => selectedAnswer.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();

  if (showSummary) {
    const percentage = Math.round((score / quiz.questions.length) * 100);
    return (
      <div className="flex flex-col h-full p-6 animate-fade-in">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Quiz Complete!</h2>
          <div className="text-6xl font-black text-primary-600 mb-4">{percentage}%</div>
          <p className="text-gray-600 dark:text-gray-300">
            You got {score} out of {quiz.questions.length} correct.
          </p>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 no-scrollbar">
          {quiz.questions.map((q, idx) => (
            <div key={q.id} className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <span className="text-sm font-semibold text-gray-500">Q{idx + 1}</span>
                <button 
                  onClick={() => onAskTutor(q)}
                  className="text-primary-600 text-xs flex items-center gap-1"
                >
                  <MessageCircle size={14} /> Explain
                </button>
              </div>
              <p className="font-medium text-gray-900 dark:text-white mb-2">{q.text}</p>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Correct: <span className="font-bold text-green-600">{q.correctAnswer}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 flex gap-3">
          <button 
            onClick={onExit}
            className="flex-1 py-3 px-6 bg-gray-200 dark:bg-slate-700 text-gray-900 dark:text-white rounded-xl font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full max-w-2xl mx-auto">
      {/* Progress Bar */}
      <div className="w-full bg-gray-200 dark:bg-slate-700 h-2 mt-4 rounded-full overflow-hidden">
        <div 
          className="bg-primary-600 h-full transition-all duration-300 ease-out"
          style={{ width: `${((currentIndex) / quiz.questions.length) * 100}%` }}
        />
      </div>

      <div className="flex justify-between items-center py-4 px-1">
        <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
          Question {currentIndex + 1} of {quiz.questions.length}
        </span>
        <span className={`text-xs px-2 py-1 rounded-full border capitalize
          ${currentQuestion.difficulty === 'hard' ? 'border-red-200 text-red-600 bg-red-50' : 
            currentQuestion.difficulty === 'medium' ? 'border-yellow-200 text-yellow-600 bg-yellow-50' : 
            'border-green-200 text-green-600 bg-green-50'}`}>
          {currentQuestion.difficulty}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto px-1 no-scrollbar pb-24">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 leading-relaxed">
          {currentQuestion.text}
        </h3>

        <div className="space-y-3">
          {(currentQuestion.type === QuestionType.MCQ || currentQuestion.type === QuestionType.TRUE_FALSE) && currentQuestion.distractors ? (
            // Render Options (Shuffled ideally, but keeping simple)
            [currentQuestion.correctAnswer, ...currentQuestion.distractors]
              .sort(() => Math.random() - 0.5)
              .map((opt, idx) => {
                const isSelected = selectedAnswer === opt;
                const showCorrect = isSubmitted && opt === currentQuestion.correctAnswer;
                const showWrong = isSubmitted && isSelected && opt !== currentQuestion.correctAnswer;

                return (
                  <button
                    key={idx}
                    disabled={isSubmitted}
                    onClick={() => setSelectedAnswer(opt)}
                    className={`w-full p-4 text-left rounded-xl border-2 transition-all duration-200
                      ${showCorrect ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : 
                        showWrong ? 'border-red-500 bg-red-50 dark:bg-red-900/20' :
                        isSelected ? 'border-primary-600 bg-primary-50 dark:bg-primary-900/20' : 
                        'border-gray-200 dark:border-slate-700 hover:border-primary-300 bg-white dark:bg-slate-800'
                      }
                    `}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-gray-800 dark:text-gray-200">{opt}</span>
                      {showCorrect && <CheckCircle className="text-green-500" size={20} />}
                      {showWrong && <XCircle className="text-red-500" size={20} />}
                    </div>
                  </button>
                );
              })
          ) : (
            // Text Input for Fill Blank / Short Answer
            <div className="relative">
              <input
                type="text"
                disabled={isSubmitted}
                value={selectedAnswer}
                onChange={(e) => setSelectedAnswer(e.target.value)}
                placeholder="Type your answer..."
                className="w-full p-4 rounded-xl border-2 border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-gray-900 dark:text-white focus:border-primary-600 focus:outline-none"
              />
              {isSubmitted && (
                <div className="mt-3 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-700 dark:text-green-300">Correct answer: {currentQuestion.correctAnswer}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Solution / Explanation */}
        {isSubmitted && (
          <div className="mt-6 p-5 bg-blue-50 dark:bg-blue-900/10 rounded-xl border border-blue-100 dark:border-blue-900/30 animate-in fade-in slide-in-from-bottom-2">
            <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2 flex items-center gap-2">
              <BookOpen size={18}/> Explanation
            </h4>
            <p className="text-blue-800 dark:text-blue-200 text-sm mb-3">{currentQuestion.explanation}</p>
            
            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Steps:</p>
              {currentQuestion.solutionSteps.map((step, i) => (
                <div key={i} className="flex gap-2 text-sm text-gray-700 dark:text-gray-300">
                  <span className="font-mono text-blue-500">{i+1}.</span>
                  <span>{step}</span>
                </div>
              ))}
            </div>

            <button 
              onClick={() => onAskTutor(currentQuestion)}
              className="mt-4 w-full py-2 bg-white dark:bg-slate-800 text-primary-600 border border-primary-200 dark:border-primary-900 rounded-lg text-sm font-medium hover:bg-primary-50 transition-colors"
            >
              Ask Tutor to explain more...
            </button>
          </div>
        )}
      </div>

      {/* Sticky Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 dark:bg-slate-900/90 backdrop-blur-lg border-t dark:border-slate-800 z-10">
        <div className="max-w-2xl mx-auto">
          {!isSubmitted ? (
            <button
              onClick={handleSubmit}
              disabled={!selectedAnswer}
              className="w-full py-3.5 bg-primary-600 text-white rounded-xl font-bold shadow-lg shadow-primary-600/30 disabled:opacity-50 disabled:shadow-none transition-all active:scale-95"
            >
              Check Answer
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="w-full py-3.5 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              {isLastQuestion ? 'Finish Quiz' : 'Next Question'} <ChevronRight size={20} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
